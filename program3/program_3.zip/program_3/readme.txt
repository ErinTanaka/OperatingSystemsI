to compile:

$ gcc smallsh.c -o smallsh
